
package org.firstinspires.ftc.teamcode.Auton;

import com.acmerobotics.roadrunner.geometry.Pose2d;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.ColorSensor;
import com.qualcomm.robotcore.hardware.DistanceSensor;
import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.AngularVelocity;
import org.firstinspires.ftc.robotcore.external.navigation.YawPitchRollAngles;
import org.firstinspires.ftc.teamcode.Core.vvHardware;
import org.firstinspires.ftc.teamcode.Core.vvHardwareRR;
import org.firstinspires.ftc.teamcode.Core.vvRoadRunnerDrive;
import org.firstinspires.ftc.teamcode.trajectorysequence.TrajectorySequence;

/**
 * Mr. Price's teleOp testing for use of switches in teleop
 *
 * Need to confirm the drive system and add the drone servo to have a full test case
 * Also need the telemetry to read all sensor values
 */

@TeleOp(name="vvTuningRR", group="Concept")

public class vvAutonTuningRR extends LinearOpMode {

    //vvHardware class external pull
    vvHardwareRR robot = new vvHardwareRR(this);

    @Override
    public void runOpMode() throws InterruptedException {

        // the amount of time the pickup takes to activate in seconds
        final double pickupTime;
        // the amount of time the arm takes to raise in seconds
        final double armTime = 2;
        final int armIdle = 0;
        final int armLow = 160; // the low encoder position for the arm, front place
        final int armHigh = 401; // the high-overhead encoder position for the arm
        final int armLift = 401; //lift location for arm
        final int armHang = 470;
        final int armStart = 25;

        ElapsedTime runtime = new ElapsedTime();

        robot.init();

        vvRoadRunnerDrive vvdrive = new vvRoadRunnerDrive(hardwareMap);

        double armEPower = 0.8;
        double pickUpPwr = 0.7;
        final int autonPickupIdle = -30; // the idle position for the pickup motor 109
        final int autonPickupHigh = -5; // the placing position for the pickup motor in the high position 148
        final int autonPickupLow = -24; // the placing position for the pickup motor in the low/forward position 5


        // Send telemetry message to signify robot waiting;
        telemetry.addData(">", "Robot Ready.  Press Play.");
        telemetry.update();

        // We want to start the bot at x: 14, y: -60, heading: 90 degrees
        Pose2d startPose = new Pose2d(14, -60, Math.toRadians(90));

        vvdrive.setPoseEstimate(startPose);

        TrajectorySequence purpleDropTop = vvdrive.trajectorySequenceBuilder(startPose)
                .forward(40)
                .back(10)
                .waitSeconds(1)
                .build();
        TrajectorySequence purpleDropLeft = vvdrive.trajectorySequenceBuilder(startPose)
                .forward(30)
                .turn(Math.toRadians(50))
                .forward(9)
                .waitSeconds(1)
                .back(3)
                .build();
        TrajectorySequence purpleDropRight = vvdrive.trajectorySequenceBuilder(startPose)
                .forward(40)
                .turn(Math.toRadians(-45))
                .back(4)
                .waitSeconds(1)
                .build();
        TrajectorySequence yellowBackDropTop = vvdrive.trajectorySequenceBuilder(purpleDropTop.end())
                .turn(Math.toRadians(90))
                .forward(48)
                .strafeRight(16)
                .forward(4)
                .build();
        TrajectorySequence yellowBackDropRight = vvdrive.trajectorySequenceBuilder(purpleDropTop.end())
                .turn(Math.toRadians(45))
                .turn(Math.toRadians(90))
                .forward(48)
                .strafeRight(6)
                .forward(4)
                .build();
        TrajectorySequence yellowBackDropLeft = vvdrive.trajectorySequenceBuilder(purpleDropTop.end())
                .turn(Math.toRadians(45))
                .strafeLeft(6)
                .forward(48)
                .strafeRight(4)
                .strafeLeft(2)
                .forward(4)
                .build();
        TrajectorySequence yellowBackDropTopRed = vvdrive.trajectorySequenceBuilder(purpleDropTop.end())
                .turn(Math.toRadians(-90))
                .forward(48)
                .strafeRight(6)
                .forward(4)
                .build();
        TrajectorySequence yellowBackDropRightRed = vvdrive.trajectorySequenceBuilder(purpleDropTop.end())
                .turn(Math.toRadians(45))
                .strafeLeft(6)
                .forward(48)
                .strafeRight(8)
                .forward(4)
                .build();
        TrajectorySequence yellowBackDropLeftRed = vvdrive.trajectorySequenceBuilder(purpleDropTop.end())
                .turn(Math.toRadians(135))
                .forward(48)
                .strafeRight(6)
                .forward(4)
                .build();
        TrajectorySequence blueEnd = vvdrive.trajectorySequenceBuilder(yellowBackDropTop.end())
                .strafeLeft(30)
                .build();
        TrajectorySequence redEnd = vvdrive.trajectorySequenceBuilder(yellowBackDropTop.end())
                .strafeRight(30)
                .build();
        // initialize all the hardware, using the hardware class. See how clean and simple this is?
        robot.init();

        // Send telemetry message to signify robot waiting;
        telemetry.addData(">", "Robot Ready.  Press Play.");
        telemetry.update();

        // Wait for the game to start (driver presses PLAY)
        waitForStart();
        if (isStopRequested()) return;
        // run until the end of the match (driver presses STOP)
        while (opModeIsActive()) {

            if (gamepad1.dpad_up) { //Stage Top
                telemetry.addLine("Running...");
                telemetry.update();
                robot.movePickUp(5, 0.5);
                robot.armPos(armStart, 0.7);
                sleep(1000);
                vvdrive.followTrajectorySequence(purpleDropTop);
                robot.movePickUp(autonPickupLow,0.7);
                sleep(500);
                robot.armPos(armIdle+5,0.5);
                robot.setPickupPower(0,-0.9);
                sleep(1000);
                robot.setPickupPower(0,0);

                //robot.armPos(armLow,armEPower); //Drive location
                //robot.movePickUp(autonPickupLow,pickUpPwr);
                //sleep(1000);
                //vvdrive.followTrajectorySequence(yellowDropTop); }

            }
            if (gamepad1.dpad_left) { //Stage Left
                robot.movePickUp(5, 0.5);
                robot.armPos(armStart, 0.7);
                sleep(1000);
                robot.movePickUp(autonPickupLow,0.7);
                vvdrive.followTrajectorySequence(purpleDropLeft);
                sleep(500);
                robot.armPos(armIdle+5,0.5);
                robot.setPickupPower(0,-0.9);
                sleep(1000);
                robot.setPickupPower(0,0);
                vvdrive.followTrajectorySequence(blueEnd);
            }
            if (gamepad1.dpad_right) { //Stage Right
                robot.movePickUp(5, 0.5);
                robot.armPos(armStart, 0.7);
                sleep(1000);
                vvdrive.followTrajectorySequence(purpleDropRight);
                robot.movePickUp(autonPickupLow,0.7);
                sleep(500);
                robot.armPos(armIdle+5,0.5);
                robot.setPickupPower(0,-0.9);
                sleep(1000);
                robot.setPickupPower(0,0);
                vvdrive.followTrajectorySequence(blueEnd);
            }
            if (gamepad1.y) { //Backdrop Top
                robot.armPos(armLow,0.7);
                robot.movePickUp(autonPickupLow,0.5);
                vvdrive.followTrajectorySequence(yellowBackDropTop);
                robot.setPickupPower(0.5,0);
                sleep(1000);
                robot.setPickupPower(0,0);
                vvdrive.followTrajectorySequence(blueEnd);
            }
            if (gamepad1.x){ //Backdrop Left
                robot.armPos(armLow,0.7);
                robot.movePickUp(autonPickupLow,0.5);
                vvdrive.followTrajectorySequence(yellowBackDropRight);
                robot.setPickupPower(0.5,0);
                sleep(1000);
                robot.setPickupPower(0,0);
                vvdrive.followTrajectorySequence(blueEnd);
            }
            if(gamepad1.b){ //Backdrop Right
                robot.armPos(armLow,0.7);
                robot.movePickUp(autonPickupLow,0.5);
                vvdrive.followTrajectorySequence(yellowBackDropLeft);
                robot.setPickupPower(0.5,0);
                sleep(1000);
                robot.setPickupPower(0,0);
                vvdrive.followTrajectorySequence(blueEnd);
            }
            if (gamepad2.y) {
                robot.armPos(armLow,0.7);
                robot.movePickUp(autonPickupLow,0.5);
                sleep(1000);
                vvdrive.followTrajectorySequence(yellowBackDropTopRed);
                robot.setPickupPower(0.5,0);
                sleep(1000);
                robot.setPickupPower(0,0);
                vvdrive.followTrajectorySequence(redEnd);
            }
            if (gamepad2.x){
                robot.armPos(armLow,0.7);
                robot.movePickUp(autonPickupLow,0.5);
                vvdrive.followTrajectorySequence(yellowBackDropRightRed);
                robot.setPickupPower(0.5,0);
                sleep(1000);
                robot.setPickupPower(0,0);
                vvdrive.followTrajectorySequence(redEnd);
            }
            if(gamepad2.b){
                robot.armPos(armLow,0.7);
                robot.movePickUp(autonPickupLow,0.5);
                vvdrive.followTrajectorySequence(yellowBackDropLeftRed);
                robot.setPickupPower(0.5,0);
                sleep(1000);
                robot.setPickupPower(0,0);
                vvdrive.followTrajectorySequence(redEnd);
            }
            if(gamepad1.left_bumper) {
                robot.armPos(armLow, 0.7);
                sleep(1000);
                robot.movePickUp(autonPickupLow, 0.7);
            };
        }
    /*public void purplePixelTop() {
            telemetry.addLine("Running...");
            telemetry.update();
            robot.movePickUp(5, 0.5);
            robot.armPos(armStart, 0.7);
            sleep(1000);
            vvdrive.followTrajectorySequence(purpleDropTop);
            robot.movePickUp(autonPickupLow,0.7);
            robot.setPickupPower(0,-0.9);
            sleep(1000);
        }*/
    }
}

